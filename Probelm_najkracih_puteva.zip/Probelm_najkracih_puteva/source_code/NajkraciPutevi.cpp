/*Problem najkracih puteva u Americi
Student: Lenka Milic
Broj indeksa: 579/2015
*/

#include <stdio.h> //FILE func f..{n,e,f}
#include <stdlib.h> //EXIT_FAILURE
#include <climits> //INT_MAX
#define MAX (INT_MAX/2)

using namespace std;

FILE *f;
int **matrix;

class MatricaVeza
{
public: int citaj();
};

class DajkstraObj
{
public: void dajkstra(int start2, int n, int **matrix, int *d, int *u);
        int sadrzi(int j, int *odvoji, int kraj);
};

//funkcija za podasavanje matrice veza
int MatricaVeza::citaj()
{

int i, j, k, m, id1, id2, rastojanje, brveza, brgradova;

f = fopen("Tema39.txt","r");
if(f == NULL)
    {
    fprintf(stderr, "Fajl nije moguce otvoriti");
    exit(EXIT_FAILURE);
    }

fscanf(f,"%d%d", &brgradova, &brveza);

//dinamicka alokacija niza nizova
// i podesavanje svih vrednosti na vrednost 0
matrix = (int **)calloc(brgradova, sizeof(int *)); 
    for(m = 0; m < brgradova; m++) 
        matrix[m] = (int *)calloc(brgradova, sizeof(int));


for(k=0; k<brveza; k++)
    {
    fscanf(f,"%d%d%d", &id1, &id2, &rastojanje);
    
	//podesavanje u implementaciji matrice ciji su elementi u opsegu od 0 do n-1,
	// u odnosu na vrednosti 1 do n koje korisnik ukucava
    matrix[id1-1][id2-1] = rastojanje; 
   
    }
// za slucaj i=j podrazumevamo duzinu gradu sa samim sobom i definisemo vrednost 0
// za slucaj kada i!=j i vrednost u matrici je 0, podrazumevamo da ne postoji direktan put
for(i=0; i<brgradova; i++)
    for(j=0; j<brgradova; j++)
    {
		if(i==j) matrix[i][j] = 0;
		else if(matrix[i][j] == 0) matrix[i][j] = MAX;
        
    }
fclose(f);
return brgradova;
}

// funkcija sadrzi ispituje da li je grad j vec posecen/oznacen
int DajkstraObj::sadrzi(int j, int *odvoji, int kraj)
{
    int i;
    for(i=0; i<=kraj; i++)
        if(j==odvoji[i]) return 1;
    return 0;
}

// funckija dajkstra za nalazenje svih najkracih puteva od startnog, zadatog grada do svih ostalih
void DajkstraObj::dajkstra(int start2, int n, int **matrix, int *d, int *u)
{
    int i, j, next, min, kraj, start;
	int *odvoji;
    //int odvoji[n];
	
	odvoji = (int*) malloc(n * sizeof(int));
	
	//podesavanje promenljive start zbog implementacije niza od 0 do n-1
	//u odnosu na to sta korisnik ukucava : od 1 do n
    start = start2-1;

	//pamcenje u nizu u[i] grada iz kog se stize u grad id
	//i pamcenje duzine puteva do gradova koji su direktno povezani sa gradom start
    for(i=0; i<n; i++)
        {
        d[i] = *(matrix[start]+i);
        if(d[i] != MAX) u[i]=start;
        }
	// nizu odvoji prikljucujemo startni grad i obelezavamo ga kao posecan
    odvoji[0] = start; kraj = 0;
    i = 0;
    do
        {
        i++;
        min = MAX;
        for(j=0; j<n; j++)
			//da li smo grad j vec posetili/oznacili, ako nismo uslov je ispunjen
			//pretraga sledeceg grada do koga je put najkraci
            if( !sadrzi(j, odvoji, kraj) )
                if( d[j] < min ) 
                {
                min = d[j]; next = j;
                }
		//promenljiva kraj prati duzinu niza odvoji[] tj.
		//u nizu odvoji moramo da ispitamo sve vrednosti pomocu funkcije sadrzi.
		//u svakoj iteraciji skupu odvoji se pridruzije jedan element
		//tako da se promenljiva kraj uslovno inkrementuje.
        kraj++;
		// u skupu odvoji se nalaze gradovi do kojih se ne moze stici putem
		//kracim nego onaj cija je duzina registrovana u nizu d[i]
        odvoji[kraj] = next;

        for(j=0; j<n; j++)
            if( !sadrzi(j,odvoji,kraj) )
				//da li je put do grada j kraci
				// 1. direktnim putem od prethodnog grada ili
				// 2. od prethodnog grada preo grada next
                if( d[j] > d[next] + *(matrix[next]+j))
                {
                d[j] = d[next] + *(matrix[next]+j);
                u[j] = next;
                }
        }
	// petlja se ponavlja n-2 puta jer je u skupu odvoji vec jedan clan od n clanova i to grad start
	//ostaje n-1 grad, medjutim kada nadjemo n-1 grad, poslednji grad n je jedinstven
    while (i != n-2);
	
	free(odvoji);
	free(matrix);
}




int main()
{

int i, n, start, cilj;
MatricaVeza M;
DajkstraObj D;
int *u;
int *d;

n = M.citaj();

u = (int*) malloc(n * sizeof(int));
d = (int*) malloc(n * sizeof(int));

int a = 0;

printf("\nKoji je startni grad: "); 
do{
	scanf("%d",&start);
	if(start > n){
		printf("Gradovi su u intervalu od 1 do 847\nPokusajte ponovo: ");
	}
	else if(start < 1){
		printf("Id grada ne moze biti negativan niti 0.\nPokusajte ponovo: ");
	}
	else a = 1;
}
while(a == 0);

D.dajkstra(start, n, matrix, d, u);

/*test
for(i=0; i<n; i++)
printf("\n%d",u[i]);*/

printf("\nUnesi do kog grada zelis put: "); scanf("%d",&cilj);
printf("Citaj put s desna u levo!\n\t");
int q = cilj-1;
printf("%d", cilj);
do
    {
    q = u[q];
	//podesavanje zbog implementacije niza od 0 do n-1
    printf("<-%d", q+1);
    }
while(q+1 != start);
printf("\n");
free(u);
free(d);

return 0;
}
